clc;
clear;
close all;

%%  FIXED PARAMETERS 
params.T1 = 298;          % K
params.P1 = 1e5;          % Pa

params.eta_c = 0.88;
params.eta_gt = 0.90;
params.eta_st = 0.92;
params.eta_p = 0.60;

params.cp = 1005;         % J/kg.K
params.gamma = 1.4;

params.T_cond = 30 + 273; % K
params.DT_pinch = 10;     % K
params.x_min = 0.92;

%%  OPTIMIZATION RANGES
params.T3 = 1200 + 273;   % One run ( loop will be applied later in code) 

x0 = [10; 8e6];           % pressure ratio, pump pressure
lb = [4; 5e6];
ub = [20; 15e6];

options = optimoptions('fmincon', ...
    'Display','iter', ...
    'Algorithm','sqp');

[xopt, fval] = fmincon( ...
    @(x) objective_combined(x,params), ...
    x0, [], [], [], [], lb, ub, ...
    @(x) constraints_combined(x,params), options);

%% RESULTS 
rp_opt = xopt(1);
Ppump_opt = xopt(2);
eta_max = -fval;

fprintf('\n--- OPTIMIZED RESULTS ---\n');
fprintf('Optimal Brayton pressure ratio = %.2f\n', rp_opt);
fprintf('Optimal Rankine pump pressure  = %.2f MPa\n', Ppump_opt/1e6);
fprintf('Maximum combined efficiency    = %.2f %%\n', eta_max*100);


T3_range = (900:100:1400) + 273;
eta_T3 = zeros(size(T3_range));

for i = 1:length(T3_range)
    params.T3 = T3_range(i);
    [~, fval] = fmincon( ...
        @(x) objective_combined(x,params), ...
        x0, [], [], [], [], lb, ub, ...
        @(x) constraints_combined(x,params), options);
    eta_T3(i) = -fval;
end

figure;
plot(T3_range-273, eta_T3*100,'-o','LineWidth',1.5);
xlabel('Gas Turbine Inlet Temperature (°C)');
ylabel('Combined Efficiency (%)');
title('Effect of T_3 on Combined Cycle Efficiency');
grid on;


% T-s plot 
figure;
plot([1 2 3 4 1],[300 600 1200 500 300],'-o');
xlabel('Entropy (arb)');
ylabel('Temperature (K)');
title('Combined Cycle T-s Diagram');
grid on;

% p-v plot 
figure;
plot([0.8 0.4 0.3 0.9 0.8],[1 10 10 1 1],'-o');
xlabel('Specific Volume (arb)');
ylabel('Pressure (bar)');
title('Combined Cycle p-v Diagram');
grid on;

function J = objective_combined(x,p)

rp = x(1);
Ppump = x(2);

%% BRAYTON CYCLE
T1 = p.T1;
T3 = p.T3;

T2s = T1 * rp^((p.gamma-1)/p.gamma);
T2  = T1 + (T2s - T1)/p.eta_c;

T4s = T3 * (1/rp)^((p.gamma-1)/p.gamma);
T4  = T3 - p.eta_gt*(T3 - T4s);

Wc = p.cp*(T2 - T1);
Wt = p.cp*(T3 - T4);

Wnet_B = Wt - Wc;
Qin_B  = p.cp*(T3 - T2);

%% RANKINE CYCLE (HRSG) 
h1 = 125;                % kJ/kg
v1 = 0.001;

Wp = (v1*(Ppump - 1e5)/1000)/p.eta_p;
h2 = h1 + Wp;

h3 = 3300;               % kJ/kg
h4s = 2100;
h4 = h3 - p.eta_st*(h3 - h4s);

Wnet_R = (h3 - h4 - Wp)*1000;

%% COMBINED 
Wnet_total = Wnet_B + Wnet_R;
eta_combined = Wnet_total / Qin_B;

J = -eta_combined;       % fmincon minimizes
end


function [c, ceq] = constraints_combined(x,p)

rp = x(1);

%% BRAYTON EXHAUST
T1 = p.T1;
T3 = p.T3;

T2s = T1 * rp^((p.gamma-1)/p.gamma);
T2  = T1 + (T2s - T1)/p.eta_c;

T4s = T3 * (1/rp)^((p.gamma-1)/p.gamma);
T4  = T3 - p.eta_gt*(T3 - T4s);

%%  PINCH POINT 
Tsteam_max = T4 - p.DT_pinch;
c1 = (500+273) - Tsteam_max;   % must be ≤ 0

%%  DRYNESS FRACTION 
h4 = 2100;
x = (h4 - 419)/2257;
c2 = p.x_min - x;              % must be ≤ 0

c = [c1; c2];
ceq = [];
end

