clc;
clear;
close all;
% INPUTS 

P_boiler = 8e6;        % Boiler pressure (Pa)
P_cond   = 10e3;       % Condenser pressure (Pa)
T3       = 480 + 273;  % Turbine inlet temperature (K)

eta_t = 0.85;          % Turbine efficiency
eta_p = 0.85;          % Pump efficiency

% State 1 : Condenser outlet 
% Saturated liquid (from steam tables)
h1 = 191.8;        % kJ/kg
s1 = 0.649;        % kJ/kg.K
v1 = 0.001;        % m^3/kg
T1 = 300;          % K (approx)

% State 2 : Pump outlet 
Wp_ideal  = v1*(P_boiler - P_cond)/1000;   % kJ/kg
Wp_actual = Wp_ideal/eta_p;

h2 = h1 + Wp_actual;
s2 = s1;
T2 = T1 + 5;       % small rise (approx)

% State 3 : Boiler outlet 
% Superheated steam (from steam tables)
h3 = 3330;         % kJ/kg
s3 = 6.7;          % kJ/kg.K
T3 = T3;

% State 4 : Turbine outlet 
% Isentropic turbine expansion
h4s = 2100;        % kJ/kg (from tables at s = s3)

Wt_actual = eta_t*(h3 - h4s);
h4 = h3 - Wt_actual;
s4 = s3 + 0.2;     % entropy increases in real turbine
T4 = 350;          % K (approx)

% PERFORMANCE PARAMETERS 
Wt   = h3 - h4;        % Turbine work (kJ/kg)
Wp   = h2 - h1;        % Pump work (kJ/kg)
Wnet = Wt - Wp;        % Net work (kJ/kg)

Qin = h3 - h2;         % Heat added (kJ/kg)

eta_th = Wnet/Qin;     % Thermal efficiency
BWR = Wp/Wt;           % Back work ratio

% displaying results 
fprintf('--- Rankine Cycle Results ---\n');
fprintf('Turbine Work        = %.2f kJ/kg\n', Wt);
fprintf('Pump Work           = %.2f kJ/kg\n', Wp);
fprintf('Net Work Output     = %.2f kJ/kg\n', Wnet);
fprintf('Heat Added          = %.2f kJ/kg\n', Qin);
fprintf('Thermal Efficiency  = %.2f %%\n', eta_th*100);
fprintf('Back Work Ratio     = %.4f\n', BWR);

% T-s DIAGRAM 
s = [s1 s2 s3 s4 s1];
T = [T1 T2 T3 T4 T1];

figure;
plot(s,T,'-o','LineWidth',1.5);
xlabel('Entropy (kJ/kg.K)');
ylabel('Temperature (K)');
title('T-s Diagram of Rankine Cycle');
grid on;

% h-s DIAGRAM 
h = [h1 h2 h3 h4 h1];

figure;
plot(s,h,'-o','LineWidth',1.5);
xlabel('Entropy (kJ/kg.K)');
ylabel('Enthalpy (kJ/kg)');
title('h-s Diagram of Rankine Cycle');
grid on;

% Parametric study : Boiler Pressure 

P_range = linspace(5e6,15e6,10);
eta_arr = zeros(size(P_range));

for i = 1:length(P_range)
    Wp_i = v1*(P_range(i)-P_cond)/1000;
    Wnet_i = Wt - Wp_i;
    eta_arr(i) = Wnet_i/Qin;
end

figure;
plot(P_range/1e6, eta_arr*100,'-o','LineWidth',1.5);
xlabel('Boiler Pressure (MPa)');
ylabel('Thermal Efficiency (%)');
title('Thermal Efficiency vs Boiler Pressure');
grid on;
