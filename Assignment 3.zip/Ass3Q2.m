clc;
clear;
close all;
% INPUTS

T1 = 288;              % Ambient temperature (K)
P1 = 1e5;              % Ambient pressure (Pa)

rp = 8;                % Pressure ratio
T3 = 1400;             % Turbine inlet temperature (K)

eta_c = 0.85;          % Compressor efficiency
eta_t = 0.88;          % Turbine efficiency

R = 287;               % J/kg.K
cp = 1005;             % J/kg.K
gamma = 1.4;

% state 1 
h1 = cp*T1;
s1 = 0;

% state 2 
P2 = rp*P1;

T2s = T1*(rp)^((gamma-1)/gamma);
T2 = T1 + (T2s - T1)/eta_c;

h2 = cp*T2;

% state 3 
P3 = P2;
h3 = cp*T3;

% State 4 : Turbine 
P4 = P1;

T4s = T3*(1/rp)^((gamma-1)/gamma);
T4 = T3 - eta_t*(T3 - T4s);

h4 = cp*T4;

% performance 
Wc = h2 - h1;        % Compressor work
Wt = h3 - h4;        % Turbine work
Wnet = Wt - Wc;      % Net work

Qin = h3 - h2;       % Heat added

eta_th = Wnet/Qin;   % Thermal efficiency
WR = Wnet/Wt;        % Work ratio

% Displaying results 
fprintf('--- Brayton Cycle Results ---\n');
fprintf('Compressor Work = %.2f kJ/kg\n', Wc/1000);
fprintf('Turbine Work    = %.2f kJ/kg\n', Wt/1000);
fprintf('Net Work        = %.2f kJ/kg\n', Wnet/1000);
fprintf('Heat Added      = %.2f kJ/kg\n', Qin/1000);
fprintf('Thermal Eff.    = %.2f %%\n', eta_th*100);
fprintf('Work Ratio      = %.3f\n', WR);

% T-s diagram 
s = [0 1.2 1.2 0.3 0];
T = [T1 T2 T3 T4 T1];

figure;
plot(s,T,'-o','LineWidth',1.5);
xlabel('Entropy (arb units)');
ylabel('Temperature (K)');
title('T-s Diagram of Brayton Cycle');
grid on;

%  P-v DIAGRAM 

v1 = R*T1/P1;
v2 = R*T2/P2;
v3 = R*T3/P3;
v4 = R*T4/P4;

v = [v1 v2 v3 v4 v1];
P = [P1 P2 P3 P4 P1]/1e5;

figure;
plot(v,P,'-o','LineWidth',1.5);
xlabel('Specific Volume (m^3/kg)');
ylabel('Pressure (bar)');
title('P-v Diagram of Brayton Cycle');
grid on;

% Presssure ratio sweep 
rp_range = linspace(2,15,20);
Wnet_arr = zeros(size(rp_range));
eta_arr = zeros(size(rp_range));

for i = 1:length(rp_range)
    rp_i = rp_range(i);
    
    T2s = T1*(rp_i)^((gamma-1)/gamma);
    T2 = T1 + (T2s - T1)/eta_c;
    
    T4s = T3*(1/rp_i)^((gamma-1)/gamma);
    T4 = T3 - eta_t*(T3 - T4s);
    
    Wc_i = cp*(T2 - T1);
    Wt_i = cp*(T3 - T4);
    
    Wnet_arr(i) = (Wt_i - Wc_i)/1000;
    eta_arr(i) = (Wt_i - Wc_i)/(cp*(T3 - T2));
end

figure;
plot(rp_range,Wnet_arr,'-o','LineWidth',1.5);
xlabel('Pressure Ratio');
ylabel('Net Work (kJ/kg)');
title('Net Work vs Pressure Ratio');
grid on;

figure;
plot(rp_range,eta_arr*100,'-o','LineWidth',1.5);
xlabel('Pressure Ratio');
ylabel('Thermal Efficiency (%)');
title('Efficiency vs Pressure Ratio');
grid on;
