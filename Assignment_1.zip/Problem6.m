% TIME GRID
t = linspace(0,4000,2000);  
% hot reservoir temperature Th and cold Tc in K 
Th = 900 - 300*exp(-0.0008*t);       
Tc = 300 + 40*sin(0.002*t);          

%Calculating heat input
Qin = 20000*(1 + 0.3*sin(0.003*t));  
% calculating efficiency
n = 1 - Tc./Th;
% Power output = efficiency * heat input 
P = n .* Qin;   
%Total work output 
W = trapz(t, P);   
% Entropy Generation 
Sgen = -(Qin./Th - Qin./Tc);  

fprintf('Total work output = %.2f kJ\n', W);
fprintf('Average efficiency = %.4f\n', mean(n));
fprintf('Average entropy generation = %.6f W/K\n', mean(Sgen));

%plots
figure;
plot(t,n,'LineWidth',1.5);
xlabel('Time (s)');
ylabel('Efficiency');
title('Efficiency variation with time');

figure;
plot(t,Sgen,'LineWidth',1.5);
xlabel('Time (s)');
ylabel('Entropy generation rate');
title('Entropy generation rate vs time');
