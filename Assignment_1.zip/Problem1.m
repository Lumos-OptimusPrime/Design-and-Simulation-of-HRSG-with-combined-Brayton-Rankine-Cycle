%% Problem 1

cv = @(T) 700 + 0.35*T - 2e-4*T.^2;  % definig the given relation 

% delta u for 320K to 820K; 
% detla T = 500 K; 

% calculating using symbolic integaration 

u_final = 700*(820) + (0.35/2)*(820^2) - (((2*10^-4)/3)*(820^3));
u_initial = 700*(320) + (0.35/2)*(320^2) - (((2*10^-4)/3)*(320^3));
deltau = u_final-u_initial;
fprintf('Analytical method result = %.4f\n', deltau);

% Calculating the numerical integration by integral method for comparison 

du = integral(cv,320,820);
error_integral = ((abs(deltau - du))/deltau)*100;
fprintf('integral() method result = %.4f\n', du);
fprintf('percentage error in integral() method = %.2f\n', error_integral );

% Calculating the numerical integration by trapz() method for comparison'

N = 10;                        % grid points
T = linspace(320,820,N);
CvT = cv(T);
du_trapz = trapz(T,CvT); 
fprintf('trapz() method result when N(grid points) is 10 : %.4f\n', du_trapz);


% calculating the minimum grid resolution that keeps numerical error below 0.1% 

% checking using different values of N
for N = 0:5:200
    T = linspace(320,820,N);
    CvT = cv(T);
    du_trapz = trapz(T,CvT);
    error_trapz = ((abs(deltau - du_trapz))/deltau)*100 ;
    if error_trapz <= 0.1
        fprintf('The minimum grid resolution that keeps numerical error below 0.1 percent = %d\n', N);
        fprintf('The error is %0.4f percent \n', error_trapz);
        break; 
    end 
end 
