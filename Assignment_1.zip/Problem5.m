cp = @(T) 1200 + 0.4*T - 1.2e-4*T.^2;   % defining cp function 
% initial and final temperatures 
T1 = 350;   
T2 = 900;
% calculating entropy change using integral()

ds = integral(@(T) cp(T)./T, T1, T2);  
% for ireversibilty fraction entropy generation 
Sgen_2  = 0.02*ds;
Sgen_10 = 0.10*ds;

T0 = 298;

% exergy destroyed = T * S generated 
Xdest_2  = T0*Sgen_2;
Xdest_10 = T0*Sgen_10;
% creating matrix to plot 
irreversibility = [2 10];         
Xdest = [Xdest_2 Xdest_10];

figure;
plot(irreversibility, Xdest,'o-','LineWidth',1.5);
xlabel('Irreversibility (%)');
ylabel('Exergy destruction');
title('Exergy destruction vs irreversibility');
grid on;

