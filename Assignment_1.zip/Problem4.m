h = @(T) 300 + 2.5*T + 0.0007*T.^2; % defining enthalpy function 
T1 = 310;
T2 = 670;
dh = h(T2) - h(T1);    % calculating enthalpy change form T1 to T2 

s = @(T) 2*log(T) + 0.001*T;     % defining entropy function 
ds = s(T2) - s(T1);              % calculating entropy change 

% since mdot >= Qdot/ Tb *  delta s 
Q = linspace(20,100,100);      
m = linspace(0.01,10,500);    
Tb = 300;

[Qm, Mm] = meshgrid(Q, m);    % calculating each possible combination 

Sgen = Mm*ds - Qm/Tb;         % entropy generation 
feasible = Sgen >= 0;         % checking entropy condition  

fprintf('Enthalpy change Δh = %.4f kJ/kg\n', dh);
fprintf('Entropy change Δs  = %.6f kJ/kg-K\n', ds);
fprintf('Bath temperature T_b = %.2f K\n', Tb);
fprintf('Heat input range = %.1f to %.1f kW\n', Q(1), Q(end));
fprintf('Mass flow range = %.2f to %.2f kg/s\n', m(1), m(end));

% plotting 
figure;
contourf(Qm, Mm, feasible, 1);
xlabel('Heat input Q (kW)');
ylabel('Mass flow rate (kg/s)');
title('Feasible operating region (Second Law)');


