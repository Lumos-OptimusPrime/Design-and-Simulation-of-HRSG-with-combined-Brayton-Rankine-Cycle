P = linspace(1,20,200);     % pressure in bar
n = 1.28;
T1 = 300;

T = T1*(P/1).^((n-1)/n);   % temperature along the path

% calculating Z compressibilty factor 

Z = 1 + 0.0008*P - 120./T;

cp = 1.05;
R  = 0.287;

dT = gradient(T);      % small temperature changes
dP = gradient(P);      % small pressure changes

% calculating entropy change change for real and ideal gas using formulas and then calculating percentage deviation 

ds_real = trapz(P, cp*dT./T - R*Z.*dP./P); 
ds_ideal = cp*log(T(end)/T1) - R*log(20/1);

percent_deviation = (abs(ds_real - ds_ideal)/abs(ds_ideal))*100;

fprintf('\nEntropy change (real gas) = %.6f kJ/kg-K\n', ds_real);
fprintf('Entropy change (ideal gas) = %.6f kJ/kg-K\n', ds_ideal);
fprintf('Percentage deviation = %.3f %%\n', percent_deviation);