Pa = 1;        
Pb = 10;       
Ta = 300;      
m  = 1.25;
 % using fsolve 

TB = fsolve(@(T) T^m*Pb^(1-m) - Ta^m*Pa^(1-m), 600);
u = @(T) 500 + 0.8*T + 1.5e-3*T^2;   
 % calcluating chnage in internal energy  
du = u(TB) - u(Ta);
R = 0.287;
% finding constant C  
va = R*Ta/Pa;
vb = R*TB/Pb;
C = Pa*va^m;
%calculating work using integral 
W = integral(@(V) C*V.^(-m), va, vb);
% heat transfer 
Q = du + W;
% analytical work for comparison 
W_analytical = R*(TB - Ta)/(1 - m);
error = abs(W - W_analytical)/abs(W_analytical)*100;

fprintf('Final temperature TB = %.2f K\n', TB);
fprintf('Change in internal energy = %.4f kJ/kg\n', du);
fprintf('Work (numerical integral) = %.4f kJ/kg\n', W);
fprintf('Work (analytical) = %.4f kJ/kg\n', W_analytical);
fprintf('Heat transfer Q = %.4f kJ/kg\n', Q);
fprintf('Percentage error in work = %.3f %%\n', error);






