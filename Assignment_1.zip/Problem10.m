% GIVEN 
Tc = 270;           
Th = 320;           
alpha = 0.02;
k = 50;

% OBJECTIVE FUNCTION
% Maximize heat delivered per unit work
% (fmincon minimizes, so we use negative)
% used chatgpt for this syntax 

objective = @(rp) -((Tc/(Th-Tc)) * ...
                   (1 - alpha*(rp-1)^2/rp)) ...
                   /(k*(sqrt(rp)-1));

% ENTROPY CONSTRAINT
% Sgen <= 0.05

function [c, ceq] = entropy_constraint(rp)
    Tc = 270; Th = 320; alpha = 0.02; k = 50;

    COP = (Tc/(Th-Tc)) * (1 - alpha*(rp-1)^2/rp);
    Wc  = k*(sqrt(rp)-1);
    Q   = COP * Wc;

    Sgen = Q/Tc - Q/Th;

    c = Sgen - 0.05;   % inequality: c <= 0
    ceq = [];
end

rp0 = 2;              % initial guess
lb = 1.1;
ub = 6;

rp_opt = fmincon(objective, 2, [], [], [], [], 1.1, 6, @entropy_constraint);

fprintf('Optimal pressure ratio = %.2f\n', rp_opt);

% plotting 

rp = linspace(1.1,6,300);

COP = (Tc./(Th-Tc)) .* (1 - alpha*(rp-1).^2 ./ rp);
Wc  = k*(sqrt(rp)-1);
Q   = COP .* Wc;
Sgen = Q./Tc - Q./Th;

% 1-D COP plot
figure;
plot(rp, COP,'LineWidth',1.5);
xlabel('Pressure ratio r_p'); ylabel('COP');
title('COP vs Pressure Ratio'); grid on;

% 1-D entropy generation plot
figure;
plot(rp, Sgen,'LineWidth',1.5); hold on;
yline(0.05,'r--','Entropy limit');
xlabel('Pressure ratio r_p'); ylabel('Entropy generation (kJ/K)');
title('Entropy Generation vs Pressure Ratio'); grid on;

% Contour plot
[RP, SG] = meshgrid(rp, linspace(min(Sgen), max(Sgen), 200));
COP_grid = (Tc./(Th-Tc)) .* (1 - alpha*(RP-1).^2 ./ RP);

figure;
contourf(RP, SG, COP_grid, 20);
colorbar; hold on;
plot(rp, Sgen,'k','LineWidth',2);
yline(0.05,'r--','Entropy limit');
xlabel('Pressure ratio r_p');
ylabel('Entropy generation (kJ/K)');
title('COP Contours with Entropy Constraint');
