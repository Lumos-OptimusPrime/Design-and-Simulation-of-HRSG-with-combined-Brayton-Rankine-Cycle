% generating synthetic data 
% took help of chatgpt for this 
c = 1.8;
R = 8.314e-3;

A_true = 1e5;
E_true = 45;

t = linspace(0,3000,150);


ode_true = @(t,T) ...
    (A_true*exp(-E_true/(R*T)) + 2000*exp(-0.001*t))/c;

[t,T_true] = ode45(ode_true, t, 300);

% adding 1% noise 

T_data = T_true .* (1 + 0.01*randn(size(T_true)));

% estimating parameters uisng lsqcurvefit 

p0 = [5e4, 30];    % initial guess

p_est = lsqcurvefit(@model, p0, t, T_data);

A_est = p_est(1);
E_est = p_est(2);

fprintf('Estimated A = %.2e\n', A_est);
fprintf('Estimated E = %.2f\n', E_est);


% function fir model used for fitting 

function Tmodel = model(params, t)

    A = params(1);
    E = params(2);

    c = 1.8;
    R = 8.314e-3;

    ode = @(t,T) ...
        (A*exp(-E/(R*T)) + 2000*exp(-0.001*t))/c;

    [~,Tmodel] = ode45(ode, t, 300);
end

