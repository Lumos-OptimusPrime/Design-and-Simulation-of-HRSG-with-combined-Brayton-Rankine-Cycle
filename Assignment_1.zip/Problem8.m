N = 50;                       % number of time steps
tf = 2000;
dt = tf/N;

q0 = ones(N,1)*(5e5/tf);      % initial guess (uniform heating)

q_opt = fmincon(@entropy_objective, q0, [], [], [], [], zeros(N,1), [], @heat_constraint);

S_uniform = entropy_objective(q0);
S_opt     = entropy_objective(q_opt);


function Sgen = entropy_objective(q)

    c = 2.5;
    Tb = 300;
    T = 300;          % initial temperature
    dt = 2000/length(q);

    Sgen = 0;

    for i = 1:length(q)
        Sgen = Sgen + (q(i)/T - q(i)/Tb)*dt;
        T = T + q(i)/c*dt;
    end
end

function [c, ceq] = heat_constraint(q)
    dt = 2000/length(q);
    c = [];
    ceq = sum(q)*dt - 5e5;
end




