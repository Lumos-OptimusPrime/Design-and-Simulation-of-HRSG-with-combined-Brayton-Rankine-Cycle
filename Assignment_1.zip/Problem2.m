% GIVEN FUNCTIONS

% Internal energy as function of temperature
uT = @(T) 450 + 1.1*T + 0.0012*T^2;

% External heat input 
qext = @(t) 5000*exp(-0.002*t);

% Reaction heat 
rT = @(T) 1500*(1 - exp(-0.01*T));

% du/dt = q_ext(t) + r(T)

dudt = @(t,u) qext(t) + rT( TfromU(u) );

% INITIAL CONDITION & TIME

T0 = 300;               % initial temperature in K 
u0 = uT(T0);            % initial internal energy
tspan = [0 4000];

% Solving ode using ode45 

[t,u] = ode45(dudt, tspan, u0);

% temperature history 

T = zeros(size(u));
for i = 1:length(u)
    T(i) = fsolve(@(Temp) uT(Temp) - u(i), 300);
end

% finding when the reaction heat is > external heat 

t_cross = NaN;

for i = 1:length(t)
    if rT(T(i)) > qext(t(i))
        t_cross = t(i);
        break;
    end
end

fprintf('Reaction heat is more than external heating at t = %.2f s\n', t_cross);

% plot

figure;
plot(t,T);
xlabel('Time (s)');
ylabel('Temperature (K)');
title('Temperature vs Time');

figure;
plot(t,qext(t),'b','LineWidth',1.5); hold on;
plot(t,rT(T),'r','LineWidth',1.5);
legend('External heating','Reaction heat');
xlabel('Time (s)');
ylabel('Heat rate (kJ/s)');
title('heat from both sources');


function T = TfromU(u)
    T = fsolve(@(T) 450 + 1.1*T + 0.0012*T^2 - u, 300);
end
